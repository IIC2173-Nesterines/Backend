echo "Stop Application"
docker compose --file docker-compose.production.yml down